import csv
import json
import os
from datetime import datetime

FILENAME = "customers.csv"
DELETED_FILE = "deleted_customers.csv"
AUTOSAVE = "autosave.json"


def ensure_files():
    if not os.path.exists(FILENAME):
        with open(FILENAME, 'w', newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Date", "Customer Name", "Amount"])

    if not os.path.exists(DELETED_FILE):
        with open(DELETED_FILE, 'w', newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Deleted Date", "Customer Name", "Amount"])

    if not os.path.exists(AUTOSAVE):
        with open(AUTOSAVE, 'w') as file:
            json.dump([], file)


def add_customer():
    name = input("Enter customer name: ")
    amount = input("Enter pending amount: ")

    with open(FILENAME, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([datetime.now().date(), name, amount])

    print("Customer added successfully")


def view_customers():
    with open(FILENAME, "r") as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            print(row)


def delete_customer():
    name = input("Enter customer name to delete: ")
    rows = []
    removed = None

    with open(FILENAME, "r") as file:
        reader = csv.reader(file)
        rows = list(reader)

    with open(FILENAME, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(rows[0])
        for row in rows[1:]:
            if row[1] == name:
                removed = row
            else:
                writer.writerow(row)

    if removed:
        with open(DELETED_FILE, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([datetime.now().date()] + removed)
        print("Customer deleted and archived.")
    else:
        print("Customer not found!")


def save_backup():
    data = []
    with open(FILENAME, "r") as file:
        reader = csv.reader(file)
        for row in reader:
            data.append(row)

    with open(AUTOSAVE, "w") as file:
        json.dump(data, file)

    print("Backup saved.")


ensure_files()

while True:
    print("\n--- PREVVXX SYSTEM ---")
    print("1. Add Customer")
    print("2. View Customers")
    print("3. Delete Customer")
    print("4. Save Backup")
    print("5. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        add_customer()
    elif choice == "2":
        view_customers()
    elif choice == "3":
        delete_customer()
    elif choice == "4":
        save_backup()
    elif choice == "5":
        print("Exiting...")
        break
    else:
        print("Invalid choice!")