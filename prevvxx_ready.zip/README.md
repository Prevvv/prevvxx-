# PREVVXX BILLING SYSTEM

This is a Python-based billing and customer tracking system that stores customer data in CSV files.

## ⭐ Features
✔ Add customer records  
✔ View records  
✔ Delete & archive data  
✔ Auto backup into JSON file

## 📁 Files
- prevvxx.py → Main program  
- customers.csv → Active customer list  
- deleted_customers.csv → Deleted records archive  
- autosave.json → Backup file

## 🏁 How to Run
1. Install Python  
2. Keep all files in same folder  
3. Run this command:  
```
python prevvxx.py
```

## Author
Created by Pratiksha
